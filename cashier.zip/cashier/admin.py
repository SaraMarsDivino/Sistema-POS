from django.contrib import admin
from .models import Venta, VentaDetalle

admin.site.register(Venta)
admin.site.register(VentaDetalle)

